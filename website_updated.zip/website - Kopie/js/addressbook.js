
function saveEntry(button) {
    var row = button.parentNode.parentNode;
    var name = row.cells[0].innerText;
    var address = row.cells[1].innerText;
    
    // Hier könnte man die Daten an den Server senden oder lokal speichern
    console.log('Gespeichert:', name, address);

    // Beispiel für eine Speicherung in LocalStorage
    localStorage.setItem(name, address);
}
